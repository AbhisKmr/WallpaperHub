package com.wallpaperhub.akaks09developers.wallpaperhub.Model;

public class BrowseModel {
    private String image_link;

    public BrowseModel() {
    }

    public BrowseModel(String image_link) {
        this.image_link = image_link;
    }

    public String getImage_link() {
        return image_link;
    }

    public void setImage_link(String image_link) {
        this.image_link = image_link;
    }
}
